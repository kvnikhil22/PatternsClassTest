import java.util.*;
/**
 * Author : Nikhil KrishnanVenkatesh (S545019)
 */
public class Factorial {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number: ");
        int num = scanner.nextInt();
        int factorial = fact(num);
        System.out.println("Factorial of the number is : "+factorial);
    }
    static int fact(int n)
    {
        if (n >= 1)
            return n * fact(n - 1);
        else
            return 1;
    }
}
